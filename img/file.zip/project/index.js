let num = 5;
num++;
console.log(num);